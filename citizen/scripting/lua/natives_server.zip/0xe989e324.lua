function Global.SetMapName(mapName)
	return _in(0xb7ba82dc, _ts(mapName))
end
