--- Immediately stops the pedestrian from whatever it's doing. They stop fighting, animations, etc. they forget what they were doing.
function Global.ClearPedTasksImmediately(ped)
	return _in(0xbc045625, ped)
end
