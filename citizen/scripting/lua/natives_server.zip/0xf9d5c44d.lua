function Global.GetVehicleLivery(vehicle)
	return _in(0xec82a51d, vehicle, _ri)
end
