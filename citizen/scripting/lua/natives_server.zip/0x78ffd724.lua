function Global.GetVehicleRadioStationIndex(vehicle)
	return _in(0x57037960, vehicle, _ri)
end
