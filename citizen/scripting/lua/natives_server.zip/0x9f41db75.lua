--- Deletes the specified entity.
-- @param entity The entity to delete.
function Global.DeleteEntity(entity)
	return _in(0xfaa3d236, entity)
end
