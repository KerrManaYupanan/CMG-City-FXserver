function Global.GetVehicleWindowTint(vehicle)
	return _in(0x13d53892, vehicle, _ri)
end
