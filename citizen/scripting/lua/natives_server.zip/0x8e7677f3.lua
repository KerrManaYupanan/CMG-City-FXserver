function Global.FindKvp(handle)
	return _in(0xbd7bebc5, handle, _s)
end
